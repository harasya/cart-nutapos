<script setup>
import StockView from '../components/StockView.vue'
</script>

<template>
  <main class="container">
    <StockView />
  </main>
</template>
